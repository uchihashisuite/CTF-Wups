function login(){
    username = document.getElementById("username").value;
    password = document.getElementById("password").value;

    data = {"username": username, "password": username}
    $.ajax({
        url: "index.php?page=login",
        data: data,
        type: 'POST',
        dataType: "json",
        success : function(data){
            if(data.success){
                console.log("Login success");
                window.location = "/index.php?page=shop";
            } else {
                console.log("Login failed");
                alert(data.error);
            }
        },
        error : function (xhr, ajaxOptions, thrownError){  
            console.log(xhr.status);          
            console.log(thrownError);
        } 
    }); 

    return false;

}


function addToCart(id=0){
    var data = {
        "item_id": id,
        "method": "add_to_cart"
    }
    $.ajax({
        url: "index.php?page=shop",
        data: data,
        type: 'POST',
        dataType: "json",
        success: function(data) {
            if (data.redirect) {
                console.log(data.redirect)
                window.location.href = data.content;
            }else{
                alert(data.content);
            }
        }
    });
}