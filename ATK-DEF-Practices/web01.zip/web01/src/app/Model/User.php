<?php
namespace App\Model;

use App\Util\Database\Database;

class User
{
    public $id;
    public $username;
    public $password;
    public $email;
    public $name;
    public $money;
    public $role;
    public $intro;


    public $guarded = array('username');
    
    function __construct($params = array())
    {
        $this->id = isset($params['id']) ? $params['id'] : 0;
        $this->username = isset($params['username']) ? $params['username'] : '';
        $this->name = isset($params['name']) ? $params['name'] : '';
        $this->password = isset($params['password']) ? $params['password'] : '';
        $this->email = isset($params['email']) ? $params['email'] : '';
        $this->money = isset($params['money']) ? $params['money'] : 1;
        $this->role = isset($params['role']) ? $params['role'] : 'user';
        $this->intro = isset($params['intro']) ? $params['intro'] : 'Chill Guy';
    }

    static function findById($id = 0)
    {
        $con = Database::newConnection();
        $sql = sprintf("select * from users where id=%d", $id);
        $user = $con->fetchOne($sql);
        $con->close();
        if(isset($user))
        {
            $_user = new User($user);
            return $_user;
        }
        return null;
    }

    static function findByUsername($username = '')
    {
        $con = Database::getInstance();
        $sql = sprintf("select * from users where username='%s'", $username);
        $user = $con->fetchOne($sql);
        if(isset($user))
        {
            $_user = new User($user);
            return $_user;
        }
        return null;
    }

    static function auth($username = '', $password = '')
    {
        $con = Database::getInstance();
        $sql = sprintf("select * from users where username='%s' and password='%s'", $username, $password);
        $user = $con->fetchOne($sql);
        if(isset($user))
        {
            $_user = new User($user);
            return $_user;
        }
        return null;
    }

    function save() {
        $con = Database::getInstance();
        $data = [$this->username, $this->password, $this->email, $this->name, 'user', $this->money,  $this->intro];
        $con->queryUpdate("insert into users(username, password, email, name, role, money, intro) values(?, ?, ?, ?, ?, ?, ?)", $data);
    }
    
    function update()
    {
        $con = Database::getInstance();
        $data = [$this->username, $this->password, $this->email, $this->name, $this->role, $this->money, $this->intro, $this->id];
        $con->queryUpdate("UPDATE users SET username=?, password=?, email=?, name=?, role=?, money=?, intro=? WHERE id=?", $data);
    }

    public function update_old()
    {
        $con = Database::getInstance();
        $data = [$this->username, $this->password, $this->email, $this->name, $this->role, $this->money, $this->intro, $this->id];
        $sql = "UPDATE users SET name = '{$this->name}', password = '{$this->password}', intro = '{$this->intro}' WHERE id = {$this->id}";
        $con->queryUpdate($sql);
    }

    function validate()
    {
        if(empty($this->email)) 
        {
            return "email empty!";
        }
        if(empty($this->password)) 
        {
            return "password empty!";
        }
        if(empty($this->name)) 
        {
            return "name empty!";
        }
        return true;
    }

    function __toString()
    {
        return $this->name;
    }
}