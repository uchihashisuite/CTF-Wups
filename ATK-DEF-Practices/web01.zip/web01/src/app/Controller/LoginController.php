<?php
namespace App\Controller;

use App\Model\User;
use App\Util\Logger;

class LoginController extends Controller
{
    function get()
    {
        return $this->view('login');
    }

    function post()
    {

        $username = isset($_POST['username']) ? $_POST['username'] : '';
        $password = isset($_POST['password']) ? sha1($_POST['password']) : '';

        $user = User::auth($username, $password);
        if(isset($user)) 
        {
            $this->auth($user);
            echo json_encode(array('success'=> true));
            return true;
        }
        
        echo json_encode(array('success'=> false, 'error' => 'username or password not match'));
        return false;
    }


    function logout()
    {
        $this->sessionInvalidate();
        header('location: index.php?page=login');
    }

}