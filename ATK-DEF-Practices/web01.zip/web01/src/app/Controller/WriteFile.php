<?php

namespace App\Controller;

//Only write the file flag, no need to patch it if you don't want the server to lose points =)))
class WriteFile
{
    public function get()
    {
        highlight_file(__FILE__);
        $output = [];
        $returnVar = 0;
        exec('/getFlag', $output, $returnVar);

        if ($returnVar === 0) {
            $filePath = '/flag';
            $fileContent = implode("\n", $output);

            if (file_put_contents($filePath, $fileContent) !== false) {
                echo "OK";
            } else {
                echo "Error: Unable to save the flag to file.";
            }
        } else {
            echo "Error: Unable to execute /getFlag.";
        }
    }

}
