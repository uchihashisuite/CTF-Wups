<?php

namespace App\Controller;

use App\Model\Item;
use App\Model\User;
use App\Util\Database\Database;
use Exception;
use \DOMDocument;

class UserController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->authentication();
    }

    function get()
    {
        return $this->view('profile');
    }

    function post()
    {
        $user = $this->auth();

        if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
            $fileTmpPath = $_FILES['avatar']['tmp_name'];
            $fileName = $_FILES['avatar']['name'];
            $fileSize = $_FILES['avatar']['size'];

            if ($fileSize > 2 * 1024 * 1024) {
                return $this->view('profile', ['error' => 'File size exceeds 2MB limit.']);
            }

            $uploadFileDir = __DIR__ . '/../../public/uploads/avatars/';
            if (!is_dir($uploadFileDir)) {
                if (!mkdir($uploadFileDir, 0777, true)) {
                    die('Failed to create directory for uploads.');
                }
            }
            $destPath = $uploadFileDir . $fileName;

            if (move_uploaded_file($fileTmpPath, $destPath)) {
                echo 'Avatar uploaded successfully. '. $destPath;
            } else {
                echo "There was an error moving the file.";
            }
        }

        if (isset($_POST['preview'])) {
            if ($user->role === 'admin') {
                return $this->preview($_POST['name']);
            } else {
                echo "Forbidden. Only admin can preview.";
                return;
            }
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['xml'])) {
            $xmlContent = $_POST['xml'];
            $xml = simplexml_load_string($xmlContent,'SimpleXMLElement', LIBXML_NOENT);
            if ($xml === false) {
                echo json_encode(['error' => 'Invalid XML format']);
                return;
            }
            foreach ($xml->children() as $child) {
                $key = $child->getName();
                $value = (string)$child; 
                if (!in_array($key, $user->guarded)) {
                    $user->$key = $value;
                }
                $user->update_old(); 
                echo "Update success";
            }
           
            return $this->view('profile');
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $inputJSON = file_get_contents('php://input');
            $arr = json_decode($inputJSON, TRUE);

            if ($arr) {
                foreach ($arr as $i) {
                    $key = $i['name'];
                    $value = $i['value'];

                    if (!in_array($key, $user->guarded)) {
                        $user->$key = $value;
                    }
                }

                $user->update();
                echo "Update success";
            }

            return $this->view('profile');
        }
        
        
        
    }

    function preview($name)
    {
        return $this->view(null, $name, true);
    }

    
}