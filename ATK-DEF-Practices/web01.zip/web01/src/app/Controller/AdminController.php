<?php

namespace App\Controller;

use App\Model\Comment;
use App\Model\Flag;

class AdminController extends Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->authentication();
    }

    function get()
    {
        $user = $this->auth();
        if ($user->role === 'admin') {
            echo file_get_contents("/flag");
        } else {
            echo "Hi ";
            return $this->block($user->name);
        }
    }

    function block($name)
    {
        return $this->view(null, $name, true);
    }

}
