package com.fptctf.chat

import org.springframework.web.bind.annotation.PostMapping
import org.springframework.web.bind.annotation.RequestBody
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/parser")
class SpellController(
    private val executor: ParserSpellExecutor
) {

    @PostMapping
    fun testSpell(@RequestBody spell: String): Any? {
        return executor.executeSpell(spell)
    }

}