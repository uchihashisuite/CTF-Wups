rootProject.name = "chat-app"
