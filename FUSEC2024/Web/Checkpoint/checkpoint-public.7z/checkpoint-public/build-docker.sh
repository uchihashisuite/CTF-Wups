#!/bin/bash
docker build --tag=ws .
docker run -p 81:80 -p 8080:8080 --rm --name=ws -it ws