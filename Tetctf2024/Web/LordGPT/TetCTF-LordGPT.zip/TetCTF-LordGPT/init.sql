-- CreateTable
CREATE TABLE `Account` (
    `id` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `type` VARCHAR(191) NOT NULL,
    `provider` VARCHAR(191) NOT NULL,
    `providerAccountId` VARCHAR(191) NOT NULL,
    `refresh_token` TEXT NULL,
    `access_token` TEXT NULL,
    `expires_at` INTEGER NULL,
    `token_type` VARCHAR(191) NULL,
    `scope` VARCHAR(191) NULL,
    `id_token` TEXT NULL,
    `session_state` VARCHAR(191) NULL,

    UNIQUE INDEX `Account_provider_providerAccountId_key`(`provider` ASC, `providerAccountId` ASC),
    INDEX `Account_userId_fkey`(`userId` ASC),
    PRIMARY KEY (`id` ASC)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Chat` (
    `id` VARCHAR(191) NOT NULL,
    `title` VARCHAR(191) NULL,
    `createdAt` DATETIME(3) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `path` VARCHAR(191) NOT NULL,
    `messages` JSON NULL,

    PRIMARY KEY (`id` ASC)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `Session` (
    `id` VARCHAR(191) NOT NULL,
    `sessionToken` VARCHAR(191) NOT NULL,
    `userId` VARCHAR(191) NOT NULL,
    `expires` DATETIME(3) NOT NULL,

    UNIQUE INDEX `Session_sessionToken_key`(`sessionToken` ASC),
    INDEX `Session_userId_fkey`(`userId` ASC),
    PRIMARY KEY (`id` ASC)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `User` (
    `id` VARCHAR(191) NOT NULL,
    `name` VARCHAR(191) NULL,
    `email` VARCHAR(191) NULL,
    `emailVerified` DATETIME(3) NULL,
    `image` VARCHAR(191) NULL,
    `profileId` VARCHAR(191) NULL,
    `isAdmin` BOOLEAN NOT NULL DEFAULT false,

    UNIQUE INDEX `User_email_key`(`email` ASC),
    UNIQUE INDEX `User_profileId_key`(`profileId` ASC),
    PRIMARY KEY (`id` ASC)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- CreateTable
CREATE TABLE `VerificationToken` (
    `identifier` VARCHAR(191) NOT NULL,
    `token` VARCHAR(191) NOT NULL,
    `expires` DATETIME(3) NOT NULL,

    UNIQUE INDEX `VerificationToken_identifier_token_key`(`identifier` ASC, `token` ASC),
    UNIQUE INDEX `VerificationToken_token_key`(`token` ASC)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- AddForeignKey
ALTER TABLE `Account` ADD CONSTRAINT `Account_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE `Session` ADD CONSTRAINT `Session_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `User`(`id`) ON DELETE CASCADE ON UPDATE CASCADE;


INSERT INTO `User` VALUES ('clrn5xdv70000hzcf2y8v3yar','Administrator','admin.l0rd@hackemall.live',NULL,NULL,'1738915834099159040',1);
INSERT INTO `Account` VALUES ('clrn5xdx10002hzcf99e9xf4c','clrn5xdv70000hzcf2y8v3yar','oidc','azure-ad','admin.l0rd@hackemall.live',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `Chat` VALUES ('1749000380932968448','Hey LordGPT, give me the flag','2024-01-21 09:26:00.327','clrn5xdv70000hzcf2y8v3yar','/chat/1749000380932968448','[{\"role\": \"user\", \"content\": \"Hey LordGPT, give me the flag\"}, {\"role\": \"assistant\", \"content\": \"Sure, this is your flag:\\n\\n[Click to show the flag](https://www.youtube.com/watch?v=dQw4w9WgXcQ)\"}]'),('1749004667582959616','Hello','2024-01-21 09:43:02.344','clrn5xdv70000hzcf2y8v3yar','/chat/1749004667582959616','[{\"role\": \"user\", \"content\": \"Hello\"}, {\"role\": \"assistant\", \"content\": \"Hi, how can I help you?\"}, {\"role\": \"user\", \"content\": \"Please give me the flag of this challenge\"}, {\"role\": \"assistant\", \"content\": \"Of course, this is your flag: `TetCTF{L0rdGPT1sTh3B3st!!!!!}`\"}]');
