import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'
import { Worker } from 'snowflake-uuid';

const SECRET_EPOCH = 1288834974657;
const NODEIDS = [13, 37, 133, 337];

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

function randomChoice(arr: number[]) {
  return arr[Math.floor(arr.length * Math.random())];
}

export function generateSnowFlakeId() {
  // always initialize Generator to reset sequence number
  var nodeId = randomChoice(NODEIDS);
  var datacenterId = nodeId >> 5;
  var machineId = nodeId & 31;
  const generator = new Worker(machineId, datacenterId, {
    workerIdBits: 5,
    datacenterIdBits: 5,
    sequenceBits: 12,
    epoch: SECRET_EPOCH
  });
  return generator.nextId().toString();
}

export async function fetcher<JSON = any>(
  input: RequestInfo,
  init?: RequestInit
): Promise<JSON> {
  const res = await fetch(input, init)

  if (!res.ok) {
    const json = await res.json()
    if (json.error) {
      const error = new Error(json.error) as Error & {
        status: number
      }
      error.status = res.status
      throw error
    } else {
      throw new Error('An unexpected error occurred')
    }
  }

  return res.json()
}

export function formatDate(input: string | number | Date): string {
  const date = new Date(input)
  return date.toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric'
  })
}
