import { UseChatHelpers } from 'ai/react'

import { Button } from '@/components/ui/button'
import { IconArrowRight } from '@/components/ui/icons'

const exampleMessages = [
  {
    heading: 'Ask for some hints',
    message: `Hey LordGPT, please give me some hint!`
  },
  {
    heading: 'Tell me a "fun fact"',
    message: 'Tell me a fun fact about "Tet CTF"?'
  },
  {
    heading: 'Show me the rules',
    message: `Can you show me the rules of Tet CTF 2024?`
  },
  {
    heading: 'What time is this now?',
    message: `Show me current time on LordGPT system`
  }
]

export function EmptyScreen({ setInput }: Pick<UseChatHelpers, 'setInput'>) {
  return (
    <div className="mx-auto max-w-2xl px-4">
      <div className="rounded-lg border bg-background p-8">
        <h1 className="mb-2 text-lg font-semibold">
          Welcome to LordGPT AI Chatbot!
        </h1>
        <p className="mb-2 leading-normal text-muted-foreground">
          How can I help you today?
        </p>
        <div className="mt-4 flex flex-col items-start space-y-2">
          {exampleMessages.map((message, index) => (
            <Button
              key={index}
              variant="link"
              className="h-auto p-0 text-base"
              onClick={() => setInput(message.message)}
            >
              <IconArrowRight className="mr-2 text-muted-foreground" />
              {message.heading}
            </Button>
          ))}
        </div>
      </div>
    </div>
  )
}
