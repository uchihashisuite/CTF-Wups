## Running locally

```bash
pnpm install
pnpm dev
```