import { OpenAIStream, StreamingTextResponse } from 'ai'
import OpenAI from 'openai'

import { auth } from '@/auth'
import { db } from '@/lib/db'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
})

export async function POST(req: Request) {
  try {
    const json = await req.json()
    const { id, messages } = json
    const userId = (await auth())?.user.id;

    if (!userId) {
      return new Response("Ohhhh no!!! Who's are you?", {
        status: 401
      })
    }

    const user = await db.user.findFirst({
      where: {
        id: userId
      }
    })

    if (user && user.isAdmin) {
      // Prevent CTF Player to make noise
      return new Response('Permission denied', {
        status: 403
      });
    }

    if (!id || !/^[0-9]{18,20}$/.test(id)) {
      return new Response('Hecker detected!!!', {
        status: 400
      });
    }

    var chat = await db.chat.findFirst({
      where: {
        id: id
      }
    });

    if (!chat) {
      chat = await db.chat.create({
        data: {
          id: id,
          userId: userId as string,
          path: `/chat/${id}`,
          title: messages[0].content.substring(0, 100),
          createdAt: new Date()
        }
      });
    }

    if (chat.userId !== userId) {
      return new Response('Hecker detected!!!', {
        status: 403
      });
    }

    const lastMessage = messages[messages.length - 1];
    if (lastMessage["role"] !== "user" || !lastMessage['content'] || lastMessage["content"].length > 4096) {
      return new Response('Hecker detected!!!', {
        status: 400
      });
    }

    await db.chat.update({
      where: {
        id: id
      },
      data: {
        messages: messages
      }
    });

    const res = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages,
      temperature: 0.7,
      stream: true
    })

    const stream = OpenAIStream(res, {
      async onCompletion(completion) {
        await db.chat.update({
          where: {
            id: id
          },
          data: {
            messages: [
              ...messages,
              {
                content: completion,
                role: 'assistant'
              }
            ]
          }
        });
      }
    })

    return new StreamingTextResponse(stream)
  } catch {
    return new Response("System error!!!", {
      status: 500
    })
  }
}
