import NextAuth from "next-auth"
import { PrismaAdapter } from "@auth/prisma-adapter"
import authConfig from "@/auth.config"
import { db } from "@/lib/db"
import { generateSnowFlakeId } from "./lib/utils"

export const {
  handlers: { GET, POST },
  auth,
  signIn,
  signOut,
  update,
} = NextAuth({
  events: {
    async createUser({ user }) {
      const profileId = generateSnowFlakeId();
      await db.user.update({
        where: { id: user.id },
        data: { profileId: profileId }
      })
    }
  },
  callbacks: {
    async signIn({ user }) {
      if (!user.email) {
        return false; // Make sure that get email successfully
      }
      return true;
    },
    async session({ session, token }) {
      if (token.sub && session.user) {
        session.user.id = String(token.sub);
      }
      return session;
    },
    async authorized({ auth }) {
      return !!auth;
    }
  },
  adapter: PrismaAdapter(db),
  session: { strategy: "jwt" },
  ...authConfig
});