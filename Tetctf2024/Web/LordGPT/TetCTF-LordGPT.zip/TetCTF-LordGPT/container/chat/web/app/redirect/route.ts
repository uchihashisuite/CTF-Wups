export async function GET(req: Request) {
    const DOMAIN = "chat.tienbip.xyz";
    let originalUrl = decodeURI(req.url);
    console.log(originalUrl);

    let url = new URL(originalUrl);
    let redirectUrl = url.searchParams.get('url');
    console.log(redirectUrl)

    if (redirectUrl) {
        if (redirectUrl.startsWith("https") === true || redirectUrl.startsWith("http") === true) {
            console.log("http");
            let url = new URL(redirectUrl);
            let host = url.host
            if (host == DOMAIN) {
                return new Response("", {
                    status: 302,
                    headers: {
                        "Location": redirectUrl
                    }
                })
            } else {
                return new Response(`Domain not belong to ${DOMAIN}`, {
                    status: 403
                })
            }
        } else if (redirectUrl.startsWith("/")) {
            console.log("/");
            return new Response("", {
                status: 302,
                headers: {
                    "Location": redirectUrl
                }
            })
        } else {
            return new Response(`Domain not belong to ${DOMAIN}`, {
                status: 403
            })
        }
    }
    return new Response("Invalid url parameter", {
        status: 403
    })
}