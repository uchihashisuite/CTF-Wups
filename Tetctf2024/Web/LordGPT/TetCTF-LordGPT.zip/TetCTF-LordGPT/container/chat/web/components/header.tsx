import * as React from 'react'
import Link from 'next/link'

import { auth } from '@/auth'
import { Button } from '@/components/ui/button'
import {
  IconOpenAI
} from '@/components/ui/icons'
import { UserMenu } from '@/components/user-menu'
import { SidebarMobile } from './sidebar-mobile'
import { SidebarToggle } from './sidebar-toggle'
import { ChatHistory } from './chat-history'
import { getUserById } from '@/data/user'

async function UserProfile() {
  const session = await auth();
  var user;
  if (session?.user) {
    user = await getUserById(session?.user.id);
  }
  return (
    <>
      <div className="flex items-center">
        {session?.user ? (
          <UserMenu user={session.user} profileId={user?.profileId ?? "undefined"} />
        ) : (
          <Button variant="link" asChild className="-ml-2">
            <Link href="/sign-in?callbackUrl=/">Login</Link>
          </Button>
        )}
      </div>
    </>
  )
}

async function UserOrLogin() {
  const session = await auth()
  return (
    <>
      {session?.user ? (
        <>
          <SidebarMobile>
            <ChatHistory userId={session.user.id} />
          </SidebarMobile>
          <SidebarToggle />
        </>
      ) : null}
      <Link href="/" target="_self">
        <Button variant="ghost" className="pl-2">
          <IconOpenAI className="w-6 h-6 mr-2"/>
          <span>LordGPT</span>
        </Button>
      </Link>
    </>
  )
}

export function Header() {
  return (
    <header className="sticky top-0 z-50 flex items-center justify-between w-full h-16 px-4 border-b shrink-0 bg-gradient-to-b from-background/10 via-background/50 to-background/80 backdrop-blur-xl">
      <div className="flex items-center">
        <React.Suspense fallback={<div className="flex-1 overflow-auto" />}>
          <UserOrLogin />
        </React.Suspense>
      </div>
      <div className="flex items-center justify-end space-x-2">
        <UserProfile />
      </div>
    </header>
  )
}
