import { notFound, redirect } from 'next/navigation'

import { auth } from '@/auth'
import { Input } from '@/components/ui/input'
import { FooterText } from '@/components/footer'
import { getUserByProfileId } from '@/data/user'


export interface ProfilePageProps {
  params: {
    id: string
  }
}

export function generateMetadata() {
  return {
    title: "Edit Profile"
  }
}

export default async function ProfilePage({ params }: ProfilePageProps) {
  const session = await auth()

  if (!session?.user) {
    redirect(`/sign-in?next=/profile/${params.id}`)
  }

  const user = await getUserByProfileId(params.id); // IDOR

  if (!user) {
    notFound()
  }

  return (
    <>
    <div className="flex-1 space-y-6">
        <div className="px-4 py-6 border-b bg-background md:px-6 md:py-8">
            <div className='relative mx-auto max-w-2xl px-4 pt-8'>
                <div className="space-y-1 md:-mx-12">
                    <h1 className="text-2xl font-bold">Edit profile</h1>
                </div>
            </div>
            <div className='relative mx-auto max-w-2xl px-4 pt-8'>
                <div className="group relative mb-4 flex items-start md:-ml-12">
                    <div className="flex h-8 w-40 shrink-0 select-none items-center justify-right bg-background">
                        <span>Profile ID:</span>
                    </div>
                    <div className="flex-1 px-1 ml-2 space-y-2 overflow-hidden">
                        <Input readOnly value={ user.profileId ?? ""}/>
                    </div>
                </div>
                <div className="group relative mb-4 flex items-start md:-ml-12">
                    <div className="flex h-8 w-40 shrink-0 select-none items-center justify-right bg-background">
                        <span>Full name:</span>
                    </div>
                    <div className="flex-1 px-1 ml-2 space-y-2 overflow-hidden">
                        <Input readOnly value={ user.name ?? ""}/>
                    </div>
                </div>
                <div className="group relative mb-4 flex items-start md:-ml-12">
                    <div className="flex h-8 w-40 shrink-0 select-none items-center justify-right bg-background">
                        <span>Email:</span>
                    </div>
                    <div className="flex-1 px-1 ml-2 space-y-2 overflow-hidden">
                        <Input readOnly value={ user.email ?? ""}/>
                    </div>
                </div>
                <div className="group relative mb-4 flex items-start md:-ml-12">
                    <div className="flex h-8 w-40 shrink-0 select-none items-center justify-right bg-background">
                        <span>Role:</span>
                    </div>
                    <div className="flex-1 px-1 ml-2 space-y-2 overflow-hidden">
                        <Input readOnly value={ user.isAdmin ? "Admin" : "User"}/>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <FooterText className="py-8" />
    </>
  )
}
