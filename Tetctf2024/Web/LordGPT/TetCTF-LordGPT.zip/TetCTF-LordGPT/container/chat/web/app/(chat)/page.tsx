import { Chat } from '@/components/chat'
import { generateSnowFlakeId } from '@/lib/utils'

export default function IndexPage() {
  const id = generateSnowFlakeId();

  return <Chat id={id} />
}
