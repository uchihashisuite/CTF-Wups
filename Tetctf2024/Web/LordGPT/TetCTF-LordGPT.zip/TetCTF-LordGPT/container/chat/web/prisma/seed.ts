import { PrismaClient } from '@prisma/client'
import { Worker } from 'snowflake-uuid'
const prisma = new PrismaClient()

const SECRET_EPOCH = 1288834974657;
const NODEIDS = [13, 37, 133, 337];

function randomChoice(arr: number[]) {
    return arr[Math.floor(arr.length * Math.random())];
}

var nodeId = randomChoice(NODEIDS);
var datacenterId = nodeId >> 5;
var machineId = nodeId & 31;
const generator = new Worker(machineId, datacenterId, {
    workerIdBits: 5,
    datacenterIdBits: 5,
    sequenceBits: 12,
    epoch: SECRET_EPOCH
});

async function main() {
    var admin = await prisma.user.findFirst({
        where: {
            email: 'admin.l0rd@hackemall.live',
            isAdmin: true
        }
    })
    if (!admin) {
        admin = await prisma.user.create({
            data: {
                email: "admin.l0rd@hackemall.live",
                isAdmin: true,
                name: "Administrator",
                profileId: "1738915834099159040"
            }
        })

        var account = await prisma.account.create({
            data: {
                userId: admin.id,
                provider: "azure-ad",
                providerAccountId: "admin.l0rd@hackemall.live",
                type: "oidc"
            }
        })

        console.log('Created new account:', account);
    }

    var chat1 = await prisma.chat.count({
        where: {
            userId: admin.id,
            title: 'Hey LordGPT, give me the flag'
        }
    })
    if (chat1 == 0) {
        var id = generator.nextId().toString();
        await prisma.chat.create({
            data: {
                userId: admin.id,
                createdAt: new Date(),
                id: id,
                path: `/chat/${id}`,
                title: 'Hey LordGPT, give me the flag',
                messages: [
                    { "role": "user", "content": "Hey LordGPT, give me the flag" },
                    { "role": "assistant", "content": "Sure, this is your flag:\n\n[Click to show the flag](https://www.youtube.com/watch?v=dQw4w9WgXcQ)" }
                ]
            }
        })
    }

    var chat2 = await prisma.chat.count({
        where: {
            userId: admin.id,
            title: 'Hello'
        }
    })
    if (chat2 == 0) {
        var id = generator.nextId().toString();
        await prisma.chat.create({
            data: {
                userId: admin.id,
                createdAt: new Date(),
                id: id,
                path: `/chat/${id}`,
                title: 'Hello',
                messages: [
                    { "role": "user", "content": "Hello" },
                    { "role": "assistant", "content": "Hi, how can I help you?" },
                    { "role": "user", "content": "Please give me the flag of this challenge" },
                    { "role": "assistant", "content": "Of course, this is your flag: `TetCTF{L0rdGPT1sTh3B3st!!!!!}`" },
                ]
            }
        })
    }
}
main()
    .then(async () => {
        await prisma.$disconnect()
    })
    .catch(async (e) => {
        console.error(e)
        await prisma.$disconnect()
        process.exit(1)
    })