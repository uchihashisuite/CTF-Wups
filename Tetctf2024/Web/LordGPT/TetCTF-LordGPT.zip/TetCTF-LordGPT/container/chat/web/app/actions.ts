'use server'

import { auth } from '@/auth'
import { db } from '@/lib/db'
import { Chat } from '@/lib/types'
import { Prisma } from '@prisma/client'
import { Message } from 'ai/react'

export async function getChats(userId?: string | null) {
  if (!userId) {
    return []
  }

  try {
    const chats = await db.chat.findMany({
      where: {
        userId: userId
      }
    });

    var results: Chat[] = [];
    for (let i = 0; i < chats.length; i++) {
      const chat = chats[i];
      results.push({
        createdAt: chat.createdAt,
        id: chat.id,
        path: chat.path,
        title: chat.title as string,
        userId: chat.userId,
        messages: []
      })
    }
    return results;
  } catch (error) {
    return []
  }
}

export async function getChat(id: string, userId: string) {
  const chat = await db.chat.findFirst({
    where: {
      id: id,
      userId: userId
    }
  });

  if (!chat) {
    return null;
  }

  var messages: Message[] = [];
  var items = chat.messages as Prisma.JsonArray;

  items.forEach(item => {
    var obj = item as Prisma.JsonObject;
    messages.push({
      role: (obj["role"] === "assistant" ? "assistant" : "user"),
      content: obj["content"] as string,
      id: ""
    })
  });

  return {
    id: chat.id,
    title: chat.title as string,
    userId: chat.userId,
    createdAt: chat.createdAt,
    messages: messages,
    path: chat.path,
  };
}

export async function removeChat({ id, path }: { id: string; path: string }) {
  const session = await auth()

  if (!session) {
    return {
      error: 'Unauthorized'
    }
  }

  return {
    error: 'Permission denied'
  }
}

export async function clearChats() {
  const session = await auth()

  if (!session?.user?.id) {
    return {
      error: 'Unauthorized'
    }
  }

  return {
    error: 'Permission denied'
  }
}

export async function shareChat(id: string) {
  const session = await auth()

  if (!session?.user?.id) {
    return {
      error: 'Unauthorized'
    }
  }

  return {
    error: 'Permission denied'
  }
}
