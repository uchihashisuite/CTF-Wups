import type { NextAuthConfig } from "next-auth";
import AzureADProvider from "next-auth/providers/azure-ad"

export default {
    providers: [
        AzureADProvider({
            clientId: process.env.AZURE_AD_CLIENT_ID,
            clientSecret: process.env.AZURE_AD_CLIENT_SECRET,
            tenantId: process.env.AZURE_AD_TENANT_ID,
            token: {
                url: "https://login.microsoftonline.com/common/oauth2/v2.0/token",
                userinfo: { url: "https://graph.microsoft.com/oidc/userinfo" },
                authorization: {
                    url: `https://login.microsoftonline.com/common/oauth2/v2.0/authorize`,
                    params: { scope: "openid profile email User.Read" },
                },
            },
            async profile(profile, tokens) {
                const response = await fetch(
                    "https://graph.microsoft.com/v1.0/me?$select=id,mail,displayName,userPrincipalName",
                    { headers: { Authorization: `Bearer ${tokens.access_token}` } }
                );
                if (response.ok) {
                    try {
                        const json = await response.json();
                        if (json.mail) {
                            profile.email = json.mail;
                        }
                    } catch { }
                }

                if (!profile.email) {
                    profile.email = profile.preferred_username;
                }

                return {
                    id: profile.email,
                    name: profile.name,
                    email: profile.email,
                    image: null,
                }
            }
        })
    ],
    pages: {
        signIn: '/sign-in' // overrides the next-auth default signin page https://authjs.dev/guides/basics/pages
    }
} satisfies NextAuthConfig