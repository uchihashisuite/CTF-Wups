import time
import random
import json
import itertools

from datetime import timedelta, datetime
from flask import Flask, request

HINT_FILES = [
    'hint1.md',
    'hint2.md',
]
RULES_FILE = 'rules.md'


app = Flask(__name__)

def delay_random():
    delay_time = random.randint(1, 50)
    time.sleep(timedelta(milliseconds=delay_time).total_seconds())

def validate_sentence(keywords, text):
    print(keywords)
    for keyword in keywords:
        if keyword not in str(text).lower():
            return False
    else:
        return True

def validate_prompt(config, text):
    for items in itertools.product(*config):
        if validate_sentence(items, text):
            return True
    else:
        return False

def get_model_data(text, is_first=False, is_stop=False):
    data = {
        "id": "chatcmpl-8hLXaiL4qSyZTDhukFzHQI8ggl9yR",
        "object": "chat.completion.chunk",
        "created": 1705341598,
        "model": "gpt-3.5-turbo-0613",
        "system_fingerprint": None,
        "choices": [
            {
                "index": 0,
                "delta": {
                    "content": text
                },
                "logprobs":None,
                "finish_reason":None
            }
        ]
    }
    if is_first:
        data['choices'][0]['delta']['role'] = 'assistant'
    if is_stop:
         data['choices'][0]['finish_reason'] = 'stop'
    return json.dumps(data, separators=(",", ":"))

def generate_response(text):
    for c in text:
        delay_random()
        yield f'data: {get_model_data(c)}\n\n'
    yield f'data: {get_model_data(None, is_stop=True)}\n\ndata: [DONE]\n\n'

def get_file_content(filename):
    with open(filename, 'r') as f:
        return f.read()


@app.route('/chat/completions', methods=['GET', 'POST'])
def chat_completions():
    try:
        data = request.json
        if 'messages' not in data or not isinstance(data['messages'], list):
            raise Exception('Invalid messages.')
        
        if len(data['messages']) == 0:
            raise Exception('Empty messages.')

        question = data['messages'][len(data['messages']) - 1]
        if 'role' not in question or 'content' not in question or question['role'] != 'user':
            raise Exception('Invalid question.')

        question = question['content']
        if len(question) > 4096:
            raise Exception('Question too long.')
        
        if validate_prompt([['can'], ['show', 'tell'], ['rule']], question):
            answer = get_file_content(RULES_FILE)
        elif validate_prompt([['what'], ['your'], ['name']], question):
            answer = "I'm called LordGPT, a product of OpenAI. How can I assist you today?"
        elif validate_prompt([['tell'], ['me'], ['fact', 'fun']], question):
            answer = "Tet CTF is a mini CTF aiming to \"lì xì\" onion/knowledge for Everyone."
        elif validate_prompt([['how', 'what'], ['flag']], question):
            answer = 'You must be Admin to ask this question!'
        elif validate_prompt([['how', 'what'], ['gen', 'generate', 'get'],['id', 'algorithm']], question):
            answer = "It's SnowFlake."
        elif validate_prompt([['give', 'show'], ['hint']], question):
            filename = random.choice(HINT_FILES)
            answer = get_file_content(filename)
        elif validate_prompt([['show', 'tell', 'what'], ['time']], question):
            current_time = str(datetime.now())
            answer = current_time
        else:
            answer = "Oh no...\nIt's seem that you are asking too hard question, please try again later!"
        
        return app.response_class(generate_response(answer), content_type='text/event-stream')
    except Exception as ex:
        print(ex)
        return app.response_class(generate_response("Oh no...\nIt seems like you're asking a difficult question. Please try again later!"), content_type='text/event-stream')


if __name__ == '__main__':
    app.run(port=5000)
