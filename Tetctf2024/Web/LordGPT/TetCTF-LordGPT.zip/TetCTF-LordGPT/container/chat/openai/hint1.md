### Hint 1:

LordGPT's journey is help Tet CTF's player to find some secret things on this system.

You must be Admin to ask any secret question :)))