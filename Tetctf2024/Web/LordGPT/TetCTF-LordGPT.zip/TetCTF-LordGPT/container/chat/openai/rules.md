### Competition Rules
🙅‍♂️ Don't delete flags or break services. While organizers try to maintain challenge resilience, mistakes will be made. Instead of abusing them, report them to the orgas for kudos.

🙅‍♂️ Don't share flags or ask for flags. It's a competition, do your personal best.

🙅‍♂️ Don't generate excessive load. Bruteforcing or DirBusting the scoreboard will not be necessary, let's keep it down.

🙅‍♂️ Don't troll, spam, flood in the chats.

🙅‍♂️ Don't register multiple accounts.


### Duration
⏰ January 27th, 2024 00:00 UTC — ⏰ January 29th, 2024 00:00 UTC (2 days)
The CTF is open to any teams, with any number of people.


### Format
Online CTF is Jeopardy-style. There will be several challenges assorted into five categories:

🔥 Web Exploit — Web technologies and vulnerabilities.

🔥 Cryptography — Crack or clone cryptographic objects or algorithms to reach the flag.

🔥 Pwnable — Binary exploiting skills.

🔥 Reverse Engineering - The process of deconstructing any engineered object to figure out the internal mechanisms.

🔥 Miscellaneous - Many challenges in CTFs will be completely random and unprecedented, requiring simply logic, knowledge, and patience to be solved. Don't be worrry, we will never release guessing challenge xD.

Each category will have three difficulty levels: Easy, Medium and Hard.

💡 Dynamic Score, Team with the highest points will win the contest

💡 Flag Format: **TetCTF{xxxxxxxxxxxxxxxxxxxxxxxxxxx}**

💡 Discord: https://discord.gg/YgWzTjC